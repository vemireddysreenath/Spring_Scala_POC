package Spring.Oracle.POC.configurations

import java.util
import java.util.{ArrayList, List}

import org.springframework.context.annotation.{Bean, Configuration}
import org.springframework.security.config.annotation.web.configuration.{EnableWebSecurity, WebSecurityConfigurerAdapter}
import org.springframework.security.core.userdetails.{User, UserDetails, UserDetailsService}
import org.springframework.security.provisioning.InMemoryUserDetailsManager


@Configuration
@EnableWebSecurity
class websecurity extends WebSecurityConfigurerAdapter{

  @Bean
  override protected def userDetailsService(): UserDetailsService = {
    var users: util.List[UserDetails] = new util.ArrayList[UserDetails]
    users.add(User.withDefaultPasswordEncoder().username("siri").password("test").roles("USER").build())

    new InMemoryUserDetailsManager(users)

  }

}
